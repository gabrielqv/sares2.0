package com.kagada.sares.ui;

import com.kagada.sares.data.Lista;
import com.kagada.sares.data.Storage;
import com.vaadin.flow.component.Key;
import com.vaadin.flow.component.Text;
import com.vaadin.flow.component.accordion.Accordion;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.H6;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.NumberField;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.Route;
import org.apache.commons.lang3.tuple.Pair;

import static javax.swing.text.html.HTML.Tag.H1;

@Route("AdminSet")
public class AdminSetMenu extends VerticalLayout {

    public AdminSetMenu() {
        HorizontalLayout prin = new HorizontalLayout();
        TextField plato = new TextField("Plato");
        NumberField cantidad = new NumberField("Cantidad");
        Button addPrin = new Button("Añadir");
//        addPrin.addClickListener(click ->
//                Storage.principales.put(plato.getValue(), cantidad.getValue().intValue())
//        );
        addPrin.addClickListener(click ->
               add( new Span(plato.getValue()))
        );
//        addPrin.addClickShortcut(Key.ENTER);
        add(new HorizontalLayout(plato,cantidad),addPrin);

//        HorizontalLayout prin = new HorizontalLayout();
        TextField plato2 = new TextField("Acompañamiento");
        NumberField cantidad2 = new NumberField("Cantidad");
        Button addPrin2 = new Button("Añadir");
        addPrin2.addClickListener(click ->
                Storage.acompañantes.put(plato2.getValue(), cantidad2.getValue().intValue())
        );
//        addPrin2.addClickShortcut(Key.ENTER);
        Button guardar = new Button("Guardar");
        guardar.addClickListener(click ->
                guardar.getUI().ifPresent(ui ->
                        ui.navigate("Admin"))
        );


        add(new HorizontalLayout(plato2,cantidad2),new HorizontalLayout(addPrin2,guardar));
//        prin.add( plato, cantidad, addPrin);

    }
}
