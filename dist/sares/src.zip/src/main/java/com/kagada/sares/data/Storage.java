package com.kagada.sares.data;

import java.util.HashMap;
import java.util.Map;

public abstract class Storage {
    static public Map<String, Integer> principales = new HashMap<String, Integer>();
    static public Map<String, Integer> acompañantes = new HashMap<String, Integer>();
}
