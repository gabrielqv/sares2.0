package com.kagada.sares.ui;

import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.Route;

@Route("AdminEdit")
public class AdminEditMenu extends VerticalLayout {

}
