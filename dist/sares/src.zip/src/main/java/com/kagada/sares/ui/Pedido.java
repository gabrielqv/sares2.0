package com.kagada.sares.ui;

import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.H3;
import com.vaadin.flow.component.html.NativeButton;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.radiobutton.RadioButtonGroup;
import com.vaadin.flow.component.radiobutton.RadioGroupVariant;
import com.vaadin.flow.router.Route;
import javafx.geometry.Side;

import static jdk.nashorn.internal.objects.ArrayBufferView.length;

@Route("Pedido")
public class Pedido extends  VerticalLayout{
    public Pedido(){
        int orderCount = 0;

        // IMPORT FROM ACOMPANAMIENTOS LIST
        String[] Principales = {"CHULETA", "PECHUGA", "ROBALO"};

        RadioButtonGroup<String> group = new RadioButtonGroup<>();
        group.setItems(Principales);
        group.setErrorMessage("El plato no esta disponible");
        group.addThemeVariants(RadioGroupVariant.LUMO_VERTICAL);
        add(group);

        String[] SidePlates = {"GARBANZOS", "TORTA", "VERDURA"};
        ComboBox<String> comboBox1 = new ComboBox<>("ACOMPAÑANTE 1");
        comboBox1.setItems(SidePlates);
        comboBox1.setValue(SidePlates[0]);
//        add(comboBox1);
        ComboBox<String> comboBox2 = new ComboBox<>("ACOMPAÑANTE 2");
        comboBox2.setItems(SidePlates);
        comboBox2.setValue(SidePlates[1]);
        add(comboBox1,comboBox2);

        Button button = new Button("AGREGAR ORDEN",
                event -> add(new Span(group.getValue()+ " " + comboBox1.getValue()+ " " + comboBox2.getValue())));
        Button returnButton = new Button("RETURN");
        returnButton.addClickListener(click -> {
            returnButton.getUI().ifPresent(ui ->
                    ui.navigate("Mesa"));
            }
        );
        button.setEnabled(false);
        group.addValueChangeListener(event -> button.setEnabled(true));
        add(new HorizontalLayout(button,returnButton));



    }

}